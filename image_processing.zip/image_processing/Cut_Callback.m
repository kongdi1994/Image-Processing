function Cut_Callback(hObject, eventdata, handles)
global T
axes(handles.axes2);
T=handles.img;
x=imcrop(handles.img);  %��ͼ
imshow(x);
handles.img=x;
guidata(hObject,handles);