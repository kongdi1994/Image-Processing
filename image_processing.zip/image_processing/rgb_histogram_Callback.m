function rgb_histogram_Callback(hObject, eventdata, handles)
global T
axes(handles.axes2);
T=handles.img;
RGB=handles.img;
R=RGB(:,:,1);
G=RGB(:,:,2);
B=RGB(:,:,3);
G1(:,:,1)=histeq(R);
G1(:,:,2)=histeq(G);
G1(:,:,3)=histeq(B);
imshow(G1);
handles.img=G1;
guidata(hObject,handles);