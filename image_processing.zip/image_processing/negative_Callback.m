function negative_Callback(hObject, eventdata, handles)
global T
axes(handles.axes2);
T=handles.img;
I=imcomplement(handles.img);
imshow(I);
handles.img=I;
guidata(hObject,handles);