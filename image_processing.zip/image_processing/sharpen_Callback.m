function sharpen_Callback(hObject, eventdata, handles)
global T
str=get(handles.ruihua2,'Value');
axes(handles.axes2);
T=handles.img;
g=handles.img;
switch str
    case 1
        h=fspecial('sobel');
    case 2
        h=fspecial('prewitt');
    case 3
        h=fspecial('laplacian');
end
if numel(size(g))>2
    R=g(:,:,1);
    G=g(:,:,2);
    B=g(:,:,3);
    R1=imfilter(R,h);
GP(:,:,1)=imadd(R,R1);
    G1=imfilter(G,h);
GP(:,:,2)=imadd(G,G1);
    B1=imfilter(B,h);
    GP(:,:,3)=imadd(B,B1);
imshow(GP);
    handles.img=GP;
else
    g1=g;
	g2=imfilter(g1,h);
    g3=imadd(g2,g1);
imshow(g3);
    handles.img=g3;
end
guidata(hObject,handles);