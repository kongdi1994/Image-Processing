function rst_Callback(hObject, eventdata, handles)
global S
y=imread(S);
axes(handles.axes2);
imshow(y);
handles.img=y;
guidata(hObject,handles);