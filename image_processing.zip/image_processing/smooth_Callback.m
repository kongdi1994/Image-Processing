function smooth_Callback(hObject, eventdata, handles)
global T
str=get(handles.pinghua2,'Value');
axes(handles.axes2);
switch str 
    case 1
        T=handles.img;
        prompt={'������ģ��ά��:'};	
        defans={'3'};
        p=inputdlg(prompt,'input',1,defans);        
        p1=str2num(p{1});
        h1=fspecial('average',[p1 p1]);
        I=imfilter(handles.img,h1);
        imshow(I);
        handles.img=I;	
        guidata(hObject,handles);
    case 2
        T=handles.img;
        prompt={'������ģ��ά��:'};
        defans={'3'};
        p=inputdlg(prompt,'input',1,defans);
        p1=str2num(p{1});
        if numel(size(handles.img))>2
            A=handles.img;
            R=A(:,:,1);
            G=A(:,:,2);
            B=A(:,:,3);
        GP(:,:,1)=medfilt2(R,[p1 p1]);
        GP(:,:,2)=medfilt2(G,[p1 p1]); 
        GP(:,:,3)=medfilt2(B,[p1 p1]);
        imshow(GP);
            handles.img=GP;
        else
            A=handles.img;
            I=medfilt2(A,[p1 p1]);
        imshow(I);
            handles.img=I;
        end
guidata(hObject,handles);
end