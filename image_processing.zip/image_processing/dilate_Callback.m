function dilate_Callback(hObject, eventdata, handles)
temp={'���ͽṹ����:'};
defans={'0'};
p=inputdlg(temp,'������',1,defans);
p1=str2num(p{1});
se=strel('line',p1,0);
I1=imdilate(handles.img,se);
global T
axes(handles.axes2);
T=handles.img;
imshow(I1);
handles.img=I1;
guidata(hObject,handles);