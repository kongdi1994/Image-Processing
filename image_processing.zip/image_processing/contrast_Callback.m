function contrast_Callback(hObject, eventdata, handles)
global T
axes(handles.axes2);
T=handles.img;
f = imadjust(T, [75/255, 160/255], [0, 1]);
imshow(f)
handles.img=f;
guidata(hObject,handles);