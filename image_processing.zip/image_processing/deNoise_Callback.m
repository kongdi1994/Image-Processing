function deNoise_Callback(hObject, eventdata, handles)
global T
str=get(handles.denoising,'Value');
axes(handles.axes2);
T=handles.img;
switch str
        case 1  
        	prompt={'������ֵ�˲�m:','������ֵ�˲�n'};
        	defans={'3','3'};
        	p=inputdlg(prompt,'input',1,defans);
        	p1=str2num(p{1});
        	p2=str2num(p{2});
        	%f=imnoise(handles.img,'gaussian',p1,p2);
            %f1=rgb2gray(handles.img);
            R=handles.img(:,:,1);
            G=handles.img(:,:,2);
            B=handles.img(:,:,3);
            f2=medfilt2(R,[p1,p2]);
            f3=medfilt2(G,[p1,p2]);
            f4=medfilt2(B,[p1,p2]); 
            f(:,:,1)=f2;
            f(:,:,2)=f3;
            f(:,:,3)=f4;
        	imshow(f);
        	handles.img=f;
        	guidata(hObject,handles);   
    	case 2  
            h = ones(5,5) / 25;
            f= imfilter(handles.img,h);
         	imshow(f);
         	handles.img=f;
         	guidata(hObject,handles);
        case 3 
        	prompt={'����ά��ֵ�˲�m:','����ά���˲�n'};
        	defans={'5','5'};
        	p=inputdlg(prompt,'input',1,defans);
        	p1=str2num(p{1});
        	p2=str2num(p{2});
        	%f=imnoise(handles.img,'gaussian',p1,p2);
            R=handles.img(:,:,1);
            G=handles.img(:,:,2);
            B=handles.img(:,:,3);
            f2=wiener2(R,[p1,p2]);
            f3=wiener2(G,[p1,p2]);
            f4=wiener2(B,[p1,p2]); 
            f(:,:,1)=f2;
            f(:,:,2)=f3;
            f(:,:,3)=f4;
        	imshow(f);
        	handles.img=f;
        	guidata(hObject,handles);                      
end
