function back_Callback(hObject,eventdata, handles)
global T
handles.img=T;
axes(handles.axes2);
imshow(T);
guidata(hObject,handles);