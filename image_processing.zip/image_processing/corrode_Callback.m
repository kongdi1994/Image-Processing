function corrode_Callback(hObject, eventdata, handles)
temp={'��ʴԲ�̰뾶:'};
defans={'0'};
p=inputdlg(temp,'������',1,defans);
p1=str2num(p{1});
se=strel('disk',p1,0);
global T
axes(handles.axes2);
T=handles.img;
I1=imerode(handles.img,se);
imshow(I1);
handles.img=I1;
guidata(hObject,handles);