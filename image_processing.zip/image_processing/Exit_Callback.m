function Exit_Callback(hObject, eventdata, handles) 
clc;
close all;
close(gcf);
clear;