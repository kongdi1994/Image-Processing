function gray_histogram_Callback(hObject, eventdata, handles)
global T
T=handles.img;
img=handles.img;
if numel(size(img))>2
    C=rgb2gray(img);
else
    C=img;
end
B=histeq(C);
axes(handles.axes2);
imshow(B);
handles.img=B;
guidata(hObject,handles);