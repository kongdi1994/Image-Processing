function rotate_Callback(hObject, eventdata,handles)
global T
T=handles.img;
str=get(handles.xuanzhuan2,'Value');
axes(handles.axes2);
prompt={'��������ת�Ƕ�:'};
defans={'0'};
p=inputdlg(prompt,'input',1,defans);
p1=str2num(p{1});
switch str
    case 2
        p1=-p1;
    case 1
        p1=p1;
end
f=imrotate(handles.img,p1,'bilinear','crop');
imshow(f);
handles.img=f;
guidata(hObject,handles);