function edge_Callback(hObject, eventdata, handles)
global T
str=get(handles.edge3,'Value');
axes(handles.axes2);
if numel(size(handles.img))>2
    I=handles.img;
    switch str 
        case 1
            T=handles.img;
        img=I;
            [x y z]=size(img);
        if z==1
        rslt=edge(img,'Roberts');
        elseif z==3
            img1=rgb2ycbcr(img);
            dx1=edge(img1(:,:,1),'Roberts');
            dx1=(dx1*255);
        img2(:,:,1)=dx1;
        img2(:,:,2)=img1(:,:,2);
        img2(:,:,3)=img1(:,:,3);
        rslt=ycbcr2rgb(uint8(img2));
        end
        imshow(rslt);
        handles.img=rslt;
        guidata(hObject,handles);
        case 2
            T=handles.img;
        img=I;
            [x y z]=size(img);
        if z==1
            rslt=edge(img,'sobel');
        elseif z==3
            img1=rgb2ycbcr(img);
            dx1=edge(img1(:,:,1),'sobel');          
            dx1=(dx1*255);
            img2(:,:,1)=dx1;
            img2(:,:,2)=img1(:,:,2);
            img2(:,:,3)=img1(:,:,3);
            rslt=ycbcr2rgb(uint8(img2));
        end
        imshow(rslt);
        handles.img=rslt;
        guidata(hObject,handles);
        case 3
            T=handles.img;
        img=I;
            [x y z]=size(img);
            if z==1
                rslt=edge(img,'Prewitt');
            elseif z==3
                img1=rgb2ycbcr(img);
                dx1=edge(img1(:,:,1),'Prewitt');
                dx1=(dx1*255);
            img2(:,:,1)=dx1;
            img2(:,:,2)=img1(:,:,2);
            img2(:,:,3)=img1(:,:,3);
            rslt=ycbcr2rgb(uint8(img2));
            end
            imshow(rslt);
            handles.img=rslt;
            guidata(hObject,handles);
        case 4
            T=handles.img;
        img=I;
            [x y z]=size(img);
            if z==1
                rslt=edge(img,'log');
            elseif z==3
                img1=rgb2ycbcr(img);
                dx1=edge(img1(:,:,1),'log');
                dx1=(dx1*255);
                img2(:,:,1)=dx1;
                img2(:,:,2)=img1(:,:,2);
                img2(:,:,3)=img1(:,:,3);
                rslt=ycbcr2rgb(uint8(img2));
            end
            imshow(rslt);
            handles.img=rslt;
            guidata(hObject,handles);
        case 5
            T=handles.img;
        img=I;
            [x y z]=size(img);
            if z==1
                rslt=edge(img,'canny');
            elseif z==3
                img1=rgb2ycbcr(img);
                dx1=edge(img1(:,:,1),'canny');
                dx1=(dx1*255);
                img2(:,:,1)=dx1;
                img2(:,:,2)=img1(:,:,2);
                img2(:,:,3)=img1(:,:,3);
                rslt=ycbcr2rgb(uint8(img2));
            end
            imshow(rslt);
            handles.img=rslt;
            guidata(hObject,handles);
    end
else
	g1=handles.img;
    switch str
        case 1
            T=handles.img;
            g2=edge(g1,'Roberts');
            imshow(g2);
            handles.img=g2;
            guidata(hObject,handles);
        case 2
            T=handles.img;
            g2=edge(g1,'sobel');
            imshow(g2);
            handles.img=g2;
            guidata(hObject,handles);
        case 3
            T=handles.img;
            g2=edge(g1,'Prewitt');
            imshow(g2);
            handles.img=g2;
            guidata(hObject,handles);
        case 4
            T=handles.img;
            g2=edge(g1,'log');
            imshow(g2);
            handles.img=g2;
            guidata(hObject,handles);
        case 5
            T=handles.img;
            g2=edge(g1,'canny');
            imshow(g2);
            handles.img=g2;
            guidata(hObject,handles);
    end
end