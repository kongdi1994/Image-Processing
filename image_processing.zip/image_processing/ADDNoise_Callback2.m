function ADDNoise_Callback2(hObject, eventdata, handles)
I=handles.img;
global T
str=get(handles.popupmenu10,'Value');
axes(handles.axes2);
switch str
        case 1  
        	T=handles.img;
        	prompt={'�����˹����1:','�����˹����2'};
        	defans={'0','0.02'};
        	p=inputdlg(prompt,'input',1,defans);
        	p1=str2num(p{1});
        	p2=str2num(p{2});
        	f=imnoise(handles.img,'gaussian',p1,p2);
        	imshow(f);
        	handles.img=f;
        	guidata(hObject,handles);   
    	case 2  
         	T=handles.img; 
         	prompt={'���뽷����������1:'};
         	defans={'0.02'};
         	p=inputdlg(prompt,'input',1,defans);
         	p1=str2num(p{1});
         	f=imnoise(handles.img,'salt & pepper',p1);
         	imshow(f);
         	handles.img=f;
         	guidata(hObject,handles);
    	case 3
        	T=handles.img;
        	prompt={'�����������1:'};
        	defans={'0.02'};
        	p=inputdlg(prompt,'input',1,defans);
        	p1=str2num(p{1});
        	f=imnoise(handles.img,'speckle',p1);
        	imshow(f);
        	handles.img=f;
        	guidata(hObject,handles); 
    	case 4
        	T=handles.img;
        	%prompt={'�����������1:'};
        	%defans={'0.02'};
        	%p=inputdlg(prompt,'input',1,defans);
        	%p1=str2num(p{1});
        	f=imnoise(handles.img,'poisson');
        	imshow(f);
        	handles.img=f;
        	guidata(hObject,handles); 
end
