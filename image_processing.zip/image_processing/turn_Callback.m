function turn_Callback(hObject, eventdata,handles)
global T
str=get(handles.fanzhuan2,'Value');
axes(handles.axes2);
I=handles.img; 
if numel(size(I))>2
switch str 
    case 1
    T=handles.img;
    b=I(:,:,1);
    c=I(:,:,2);
    d=I(:,:,3);
I1(:,:,1)=fliplr(b);
I1(:,:,2)=fliplr(c);
I1(:,:,3)=fliplr(d);
    case 2
    T=handles.img; 
    b=I(:,:,1);
    c=I(:,:,2);
    d=I(:,:,3);
I1(:,:,1)=flipud(b);
I1(:,:,2)=flipud(c);
I1(:,:,3)=flipud(d);
end
imshow(I1);
handles.img=I1;
guidata(hObject,handles);
else
    switch str 
        case 1
            T=handles.img;
            f=fliplr(I);
        case 2
            T=handles.img;
            f=flipud(I);
    end
imshow(f);
handles.img=f;
guidata(hObject,handles);
end